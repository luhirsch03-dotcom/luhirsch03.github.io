package Controlador;

import Vista.*;
import Modelo.*;

public class Principal {
	Coordinador miCoordinador;
	VentanaPrincipal miVentanaPrincipal;
	VentanaMovimiento miVentanaMovimiento;
	VentanaProveedores miVentanaProveedores;
	VentanaProducto miVentanaProducto;
	VentanaEditarProducto miVentanaEditarProducto;
	Logica miLogica;
	VentanaBuscarProveedor miVentanaBuscarProveedor;
	VentanaBuscarProductos miVentanaBuscarProductos;
	Reportes miReporte;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Principal miPrincipal = new Principal();
		miPrincipal.iniciar();
	}

	private void iniciar() {
		// TODO Auto-generated method stub
		miVentanaPrincipal = new VentanaPrincipal();
		miVentanaMovimiento = new VentanaMovimiento();
		miVentanaProveedores = new VentanaProveedores();
		miVentanaProducto = new VentanaProducto();
		miVentanaEditarProducto = new VentanaEditarProducto();
		miCoordinador = new Coordinador();
		miLogica = new Logica();
		miVentanaBuscarProveedor = new VentanaBuscarProveedor();
		miVentanaBuscarProductos = new VentanaBuscarProductos();
		miReporte = new Reportes();
		
		
		miCoordinador.setMiVentanaMovimiento(miVentanaMovimiento);
		miCoordinador.setMiVentanaPrincipal(miVentanaPrincipal);
		miCoordinador.setMiVentanaProveedores(miVentanaProveedores);
		miCoordinador.setMiVentanaProducto(miVentanaProducto);
		miCoordinador.setMiVentanaEditarProducto(miVentanaEditarProducto);
		miCoordinador.setMiLogica(miLogica);
		miCoordinador.setMiVentanaBuscarProveedor(miVentanaBuscarProveedor);
		miCoordinador.setMiVentanaBuscarProductos(miVentanaBuscarProductos);
		miCoordinador.setMiReporte(miReporte);
		
		
		miVentanaPrincipal.setMiCoordinador(miCoordinador);
		miVentanaMovimiento.setMiCoordinador(miCoordinador);
		miVentanaProveedores.setMiCoordinador(miCoordinador);
		miVentanaProducto.setMiCoordinador(miCoordinador);
		miLogica.setMiCoordinador(miCoordinador);
		miVentanaEditarProducto.setMiCoordinador(miCoordinador);
		miVentanaBuscarProveedor.setMiCoordinador(miCoordinador);
		miVentanaBuscarProductos.setMiCoordinador(miCoordinador);
		miReporte.setMiCoordinador(miCoordinador);
		
		miVentanaPrincipal.setVisible(true);
	}

}
