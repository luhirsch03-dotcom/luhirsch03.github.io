package Controlador;

import java.awt.event.MouseEvent;

import Modelo.*;
import Vista.*;


public class Coordinador {
	private VentanaPrincipal miVentanaPrincipal;
	private VentanaMovimiento miVentanaMovimiento;
	private VentanaProveedores miVentanaProveedores;
	private VentanaProducto miVentanaProducto;
	private VentanaEditarProducto miVentanaEditarProducto;
	private Logica miLogica;
	private VentanaBuscarProveedor miVentanaBuscarProveedor;
	private VentanaBuscarProductos miVentanaBuscarProductos;
	private Reportes miReporte;
	
	
	public VentanaPrincipal getMiVentanaPrincipal() {
		return miVentanaPrincipal;
	}
	public void setMiVentanaPrincipal(VentanaPrincipal miVentanaPrincipal) {
		this.miVentanaPrincipal = miVentanaPrincipal;
	}
	public VentanaMovimiento getMiVentanaMovimiento() {
		return miVentanaMovimiento;
	}
	public void setMiVentanaMovimiento(VentanaMovimiento miVentanaMovimiento) {
		this.miVentanaMovimiento = miVentanaMovimiento;
	}
	public VentanaProveedores getMiVentanaProveedores() {
		return miVentanaProveedores;
	}
	public void setMiVentanaProveedores(VentanaProveedores miVentanaProveedores) {
		this.miVentanaProveedores = miVentanaProveedores;
	}
	public VentanaProducto getMiVentanaProducto() {
		return miVentanaProducto;
	}
	public void setMiVentanaProducto(VentanaProducto miVentanaProducto) {
		this.miVentanaProducto = miVentanaProducto;
	}
	public VentanaEditarProducto getMiVentanaEditarProducto() {
		return miVentanaEditarProducto;
	}
	public void setMiVentanaEditarProducto(VentanaEditarProducto miVentanaEditarProducto) {
		this.miVentanaEditarProducto = miVentanaEditarProducto;
	}
	public Logica getMiLogica() {
		return miLogica;
	}
	public void setMiLogica(Logica miLogica) {
		this.miLogica = miLogica;
	}
	
	public VentanaBuscarProveedor getMiVentanaBuscarProveedor() {
		return miVentanaBuscarProveedor;
	}
	public void setMiVentanaBuscarProveedor(VentanaBuscarProveedor miVentanaBuscarProveedor) {
		this.miVentanaBuscarProveedor = miVentanaBuscarProveedor;
	}
	
	
	public VentanaBuscarProductos getMiVentanaBuscarProductos() {
		return miVentanaBuscarProductos;
	}
	public void setMiVentanaBuscarProductos(VentanaBuscarProductos miVentanaBuscarProductos) {
		this.miVentanaBuscarProductos = miVentanaBuscarProductos;
	}
	
	
	
	
	
	
	public Reportes getMiReporte() {
		return miReporte;
	}
	public void setMiReporte(Reportes miReporte) {
		this.miReporte = miReporte;
	}
	public void mostrarVentanaProducto() {
		// TODO Auto-generated method stub
		miVentanaProducto.setVisible(true);
		miVentanaProducto.mostrarDatosConTableModel();
	}
	public void mostrarVentanaProveedores() {
		// TODO Auto-generated method stub
		miVentanaProveedores.setVisible(true);
	}
	public void mostrarVentanaMovimiento() {
		// TODO Auto-generated method stub
		miVentanaMovimiento.setVisible(true);
	}
	public void mostrarVentanaEditarProducto() {
		// TODO Auto-generated method stub
		miVentanaEditarProducto.setVisible(true);
	}
	public void mostrarVentanaBuscarProveedor() {
		// TODO Auto-generated method stub
		miVentanaBuscarProveedor.setVisible(true);
		miVentanaBuscarProveedor.mostrarDatosConTableModel();
	}
	public void mostrarVentanaBuscarProducto() {
		// TODO Auto-generated method stub
		miVentanaBuscarProductos.setVisible(true);
		miVentanaBuscarProductos.mostrarDatosConTableModel();
	}
	
	
	
//Hacen la conexion con la base de datos
	//Ventana Producto
    public void agregarProducto(ProductosVO miProductoVO) {
    	ProductosDAO miProductoDAO = new ProductosDAO();
    	miProductoDAO.AgregarProducto(miProductoVO);
	
    }
	public void eliminarProducto(Integer id) {
		// TODO Auto-generated method stub
		ProductosDAO miProductoDAO = new ProductosDAO();
    	miProductoDAO.eliminarProducto(id);
	
	}
	public void pasarDatosProductos(ProductosVO miProductoVO) {
		// TODO Auto-generated method stub
		miVentanaProducto.muestraProducto(miProductoVO);
		miVentanaMovimiento.muestraProductos(miProductoVO);
	}
	public void EditarProducto(ProductosVO miProductoVo) {
		// TODO Auto-generated method stub
		ProductosDAO miProductoDAO = new ProductosDAO();
		miProductoDAO.EditarProducto(miProductoVo);
		
	}
	
	
	
	
	//Ventana Proveedor
	public void agregarProveedor (ProveedorVO miProveedorVO) {
	ProveedorDAO miProveedorDAO = new ProveedorDAO();
	miProveedorDAO.agregarProveedor(miProveedorVO);
	}
	public void BuscarProveedor (int idProveedor, VentanaProveedores ventana) {
		ProveedorDAO miProveedorDAO = new ProveedorDAO();
		miProveedorDAO.BuscarProveedor(idProveedor, ventana);
	}
	public void pasarDatosProveedor(ProveedorVO miProveedorVO) {
		// TODO Auto-generated method stub
		miVentanaProveedores.mostrarProveedores(miProveedorVO);
		miVentanaMovimiento.mostrarProveedores(miProveedorVO);
	}
	public void eliminarProveedor(Integer id) {
		// TODO Auto-generated method stub
		ProveedorDAO miProveedorDAO = new ProveedorDAO();
		miProveedorDAO.eliminarProveedor(id);
		
	}
	public void agregarMovimiento(MovimientoVO miMovimientoVO) {
		MovimientoDAO miMovimientoDAO = new MovimientoDAO();
		miMovimientoDAO.agregarMovimiento(miMovimientoVO);
		
	}
	
	
	
	
	
	
}

