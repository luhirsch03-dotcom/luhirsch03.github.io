package Modelo;

import java.util.Date;

import javax.swing.JOptionPane;

import Controlador.Coordinador;


public class Logica {
	Coordinador miCoordinador;
	
	public Coordinador getMiCoordinador() {
		return miCoordinador;
	}

	public void setMiCoordinador(Coordinador miCoordinador) {
		this.miCoordinador = miCoordinador;
	}
	
	public void verificarDatos(ProductosVO miProductosVo) {
		//Este método recibe un objeto de tipo AlumnoVO y realiza las siguientes acciones
		String msg="";
		boolean hayError=false;
		 if(miProductosVo.getNombre().isEmpty()) {
			 msg+="\n No se ingreso nombre del producto";
			 hayError = true;
			/* Verifica si el campo de nombre del objeto productosVO está vacío.
			 *  Si está vacío, agrega un mensaje de error a msg y establece hayError a true.*/
		 }
		 if (hayError){
				JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
		 }
		//Si hayError es true, muestra un cuadro de diálogo con los mensajes de error acumulados en msg.
		 
		 else {
			 ProductosDAO miProductoDAO;
			 miProductoDAO = new ProductosDAO();}
		 }
		 /*Si no hay errores (hayError es false),
		  *  se crea un objeto de tipo ProductosDAO y se llama (comentado) al método
		  *   AgregarProducto para agregar el objeto ProductoVO.*/
		 
		 public void verificarDatos1(ProveedorVO miProveedorVo) {
				//Este método recibe un objeto de tipo AlumnoVO y realiza las siguientes acciones
				String msg="";
				boolean hayError=false;
				 if(miProveedorVo.getNombre().isEmpty()) {
					 msg+="\n No se ingreso nombre del proveedor";
					 hayError = true;
					/* Verifica si el campo de nombre del objeto productosVO está vacío.
					 *  Si está vacío, agrega un mensaje de error a msg y establece hayError a true.*/
				 }
				 if (hayError){
						JOptionPane.showMessageDialog(null, msg, "Error", JOptionPane.ERROR_MESSAGE);
				 }
				//Si hayError es true, muestra un cuadro de diálogo con los mensajes de error acumulados en msg.
				 
				 else {
					 ProveedorDAO miProveedorDAO;
					 miProveedorDAO = new ProveedorDAO();
				 }
		 
	}}

