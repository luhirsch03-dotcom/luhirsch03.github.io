package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.sql.SQLInvalidAuthorizationSpecException;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Vista.VentanaEditarProducto;

public class ProductosDAO {

	public void AgregarProducto(ProductosVO miProductoVo) {

	    try {
	        Conexion conex = new Conexion();
	        String sql = "INSERT INTO productos (idProducto, nombre, descripcion, precioUnitario, stock) VALUES (?, ?, ?, ?, ?)";
	        PreparedStatement ps = conex.getConnection().prepareStatement(sql);

	     // Establecer los valores para cada parámetro 
	        ps.setInt(1, miProductoVo.getIdProducto());
	        ps.setString(2, miProductoVo.getNombre()); 
	        ps.setString(3, miProductoVo.getDescripcion()); 
	        ps.setDouble(4, miProductoVo.getPrecioUnitario());
	        ps.setInt(5, miProductoVo.getStock()); 
	        
	        
	        ps.executeUpdate();

	        JOptionPane.showMessageDialog(null, "Se registró el producto", "Información", JOptionPane.INFORMATION_MESSAGE);
	        ps.close();
	        conex.desconectar();
	    } catch (SQLException e) {
	        JOptionPane.showMessageDialog(null, "No se pudo registrar el producto");
	        e.printStackTrace();
	    }
	}
	public void añadirTablaProductos(DefaultTableModel modelo) {
	    try {
	        Conexion conex = new Conexion();
	        Statement estatuto = conex.getConnection().createStatement();

	        // Ejecutar la consulta SQL
	        ResultSet res = estatuto.executeQuery("SELECT idProducto, nombre, descripcion, precioUnitario, stock FROM productos ORDER BY idProducto ASC");

	        // Procesar los resultados de la consulta
	        while (res.next()) {
	            Object fila[] = new Object[5];
	            for (int i = 0; i < 5; i++) {
	                fila[i] = res.getObject(i + 1);
	            }
	            modelo.addRow(fila);
	        }

	        // Cerrar recursos
	        res.close();
	        estatuto.close();
	        conex.desconectar();

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	public void EditarProducto(ProductosVO miProductosVo) {
	    try {
	        Conexion conex = new Conexion();
	        String consulta = "UPDATE productos SET PrecioUnitario=?, Stock=? WHERE idProducto=?";
	        PreparedStatement estatuto = conex.getConnection().prepareStatement(consulta);

	        // Validación de datos (ejemplo)
	        if (miProductosVo.getPrecioUnitario() <= 0 || miProductosVo.getStock() < 0) {
	            throw new IllegalArgumentException("Precio unitario y stock deben ser valores positivos.");
	        }

	        // Asignación de parámetros en el orden correcto
	        estatuto.setDouble(1, miProductosVo.getPrecioUnitario());
	        estatuto.setInt(2, miProductosVo.getStock());
	        estatuto.setInt(3, miProductosVo.getIdProducto());

	        int filasActualizadas = estatuto.executeUpdate();

	        if (filasActualizadas > 0) {
	            JOptionPane.showMessageDialog(null, "Se ha modificado el producto correctamente.", "Confirmación", JOptionPane.INFORMATION_MESSAGE);
	        } else {
	            JOptionPane.showMessageDialog(null, "No se encontró ningún producto con el ID especificado.", "Información", JOptionPane.INFORMATION_MESSAGE);
	        }

	    } catch (SQLException e) {
	        JOptionPane.showMessageDialog(null, "Error al modificar el producto: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    } catch (IllegalArgumentException e) {
	        JOptionPane.showMessageDialog(null, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	    }
	}
	public void eliminarProducto(Integer id) {
		try {
			Conexion conex = new Conexion();
			Statement estatuto=conex.getConnection().createStatement();
			estatuto.executeUpdate("DELETE FROM productos WHERE idProducto='"+id+"'");
			JOptionPane.showMessageDialog(null, "Se elimino");
			estatuto.close();
			conex.desconectar();
	} catch (SQLException e) {
		JOptionPane.showMessageDialog(null, "No se elimino");
	}
	}
	public void BuscarProducto(int idProducto, VentanaEditarProducto ventana) {
	        try {
	        	 // Validación del ID del producto
	            if (idProducto <= 0) {
	                throw new IllegalArgumentException("El ID del producto debe ser un número positivo.");
	                }
	            Conexion conex = new Conexion();
	       

	            String consulta = "SELECT * FROM productos WHERE idProducto = ?";
	            PreparedStatement estatuto = conex.getConnection().prepareStatement(consulta);
	            estatuto.setInt(1, idProducto);

	            ResultSet res = estatuto.executeQuery();

	            if (res.next()) {
	                ventana.setIdProducto(String.valueOf(res.getInt("idProducto")));
	                ventana.setNombreViejo(res.getString("nombre"));
	                ventana.setDescripcionVieja(res.getString("descripcion"));
	                ventana.setPrecioUnidadViejo(String.valueOf(res.getDouble("precioUnitario")));
	                ventana.setStockViejo(String.valueOf(res.getInt("stock")));
	            } else {
	                JOptionPane.showMessageDialog(null, "Producto no encontrado");
	            }

	            res.close();
	            estatuto.close();
	            conex.desconectar();
	        } catch (SQLException e) {
	            JOptionPane.showMessageDialog(null, "Error al buscar el producto: " + e.getMessage());
	        } catch (IllegalArgumentException | NoSuchElementException e) {
	            JOptionPane.showMessageDialog(null, e.getMessage());
	        } finally {
	            
	        	}
	        }
	    }
	        
		


	