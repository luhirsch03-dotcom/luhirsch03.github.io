package Modelo;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;



public class MovimientoDAO {
	public void agregarMovimiento(MovimientoVO miMovimientoVO) {
		
			  try {
				  Conexion conex = new Conexion(); 
				  String consulta = "INSERT INTO movimiento (idProducto, idProveedor, tipoMovimiento, fecha, cantidad) VALUES (?, ?, ?, ?, ?)"; PreparedStatement ps = conex.getConnection().prepareStatement(consulta);
			     // Establecer los valores para cada parámetro 
				  	
			        ps.setInt(1,miMovimientoVO.getIdProducto());
			        ps.setInt(2,miMovimientoVO.getIdProveedor());
			        java.sql.Date dia = new java.sql.Date(miMovimientoVO.getFecha().getTime());
			        ps.setDate(3, dia);
			        ps.setString(4, miMovimientoVO.getTipoMovimiento());
			        ps.setInt(5, miMovimientoVO.getCantidad());
			        
			        ps.executeUpdate();
			       	
			        JOptionPane.showMessageDialog(null, "movimiento registrado", "Información", JOptionPane.INFORMATION_MESSAGE);
		        } catch (SQLException e) {
		            // Manejar diferentes tipos de excepciones y mostrar mensajes más específicos
		            if (e.getErrorCode()== 1062) /* Código de error para clave duplicada */ {
		                JOptionPane.showMessageDialog(null, "Ya existe un movimiento con ese nombre.");
		            } else {
		                JOptionPane.showMessageDialog(null, "Error al guardar el movimiento: " + e.getMessage());
		            }
		            e.printStackTrace();
			  }}
		    }
	

