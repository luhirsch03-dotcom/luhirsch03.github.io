package Modelo;

import Controlador.Coordinador;

public class Reportes {
	private Coordinador miCoordinado; 

	public void setMiCoordinador(Coordinador miCoordinador) {
		// TODO Auto-generated method stub
		
	}

	public Coordinador getMiCoordinado() {
		return miCoordinado;
	}

}
