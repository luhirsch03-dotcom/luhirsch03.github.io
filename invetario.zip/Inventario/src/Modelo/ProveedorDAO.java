package Modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Vista.VentanaEditarProducto;
import Vista.VentanaProveedores;

public class ProveedorDAO {

	public void agregarProveedor (ProveedorVO miProveedorVO) {
		  try {
		        Conexion conex = new Conexion();
		        String consulta = "INSERT INTO proveedor (idProveedor, nombre, contacto, direccion) VALUES (?, ?, ?, ?)";
		        PreparedStatement ps = conex.getConnection().prepareStatement(consulta);

		     // Establecer los valores para cada parámetro 
		        ps.setInt(1,miProveedorVO.getIdProveedor());
		        ps.setString(2, miProveedorVO.getNombre());
		        ps.setString(3, miProveedorVO.getContacto());
		        ps.setString(4, miProveedorVO.getDireccion());
		        
		        ps.executeUpdate();

		        JOptionPane.showMessageDialog(null, "Se ha registrado el Proveedor", "Información", JOptionPane.INFORMATION_MESSAGE);
	        } catch (SQLException e) {
	            // Manejar diferentes tipos de excepciones y mostrar mensajes más específicos
	            if (e.getErrorCode()== 1062) /* Código de error para clave duplicada */ {
	                JOptionPane.showMessageDialog(null, "Ya existe un proveedor con ese nombre.");
	            } else {
	                JOptionPane.showMessageDialog(null, "Error al registrar el proveedor: " + e.getMessage());
	            }
	            e.printStackTrace();
	        }
	    }
	public void eliminarProveedor(Integer id) {
		try {
			Conexion conex = new Conexion();
			Statement estatuto=conex.getConnection().createStatement();
			estatuto.executeUpdate("DELETE FROM proveedor WHERE idProveedor='"+id+"'");
			JOptionPane.showMessageDialog(null, "Se elimino");
			estatuto.close();
			conex.desconectar();
	} catch (SQLException e) {
		JOptionPane.showMessageDialog(null, "No se elimino");}
	}
	public void BuscarProveedor(int idProveedor, VentanaProveedores ventana) {
		        try {
		        	 // Validación del ID del producto
		            if (idProveedor <= 0) {
		                throw new IllegalArgumentException("El ID del producto debe ser un número positivo.");
		                }
		            Conexion conex = new Conexion();
		       

		            String consulta = "SELECT * FROM proveedor WHERE idProveedor = ?";
		            PreparedStatement estatuto = conex.getConnection().prepareStatement(consulta);
		            estatuto.setInt(1, idProveedor);

		            ResultSet res = estatuto.executeQuery();

		            if (res.next()) {
		                ventana.setNombre(res.getString("nombre"));
		                ventana.setContacto(res.getString("contacto"));
		               ventana.setDireccion(res.getString("direccion"));
		            } else {
		                JOptionPane.showMessageDialog(null, "Proveedor no encontrado");
		            }

		            res.close();
		            estatuto.close();
		            conex.desconectar();
		        } catch (SQLException e) {
		            JOptionPane.showMessageDialog(null, "Error al buscar el proveedor: " + e.getMessage());
		        } catch (IllegalArgumentException | NoSuchElementException e) {
		            JOptionPane.showMessageDialog(null, e.getMessage());
		        } finally {
		            
		        	}
	} 
	public void añadirTablaProveedor(DefaultTableModel modelo) {
    try {
        Conexion conex = new Conexion();
        Statement estatuto = conex.getConnection().createStatement();

        // Ejecutar la consulta SQL
        ResultSet res = estatuto.executeQuery("SELECT idProveedor, nombre, contacto, direccion FROM proveedor ORDER BY idProveedor ASC");

        // Procesar los resultados de la consulta
        while (res.next()) {
            Object fila[] = new Object[4];
            for (int i = 0; i < 4; i++) {
                fila[i] = res.getObject(i + 1);
            }
            modelo.addRow(fila);
        }

        // Cerrar recursos
        res.close();
        estatuto.close();
        conex.desconectar();

    } catch (SQLException e) {
        e.printStackTrace();
    }
}

	}