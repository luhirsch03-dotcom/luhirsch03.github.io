package Vista;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Controlador.Coordinador;
import Modelo.ProveedorDAO;
import Modelo.ProveedorVO;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaBuscarProveedor extends JFrame {

	private JPanel contentPane;
	private Coordinador miCoordinador;
	private JScrollPane scrollPane;
	private JTable tablaProveedores; 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaBuscarProveedor frame = new VentanaBuscarProveedor();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaBuscarProveedor() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 482, 326);
		contentPane = new JPanel();
		setLocationRelativeTo(null);
		setResizable(false);
		contentPane.setBackground(new Color(201, 230, 231));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 448, 221);
		contentPane.add(scrollPane);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				volver();
			}
		});
		btnVolver.setForeground(new Color(30, 55, 51));
		btnVolver.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnVolver.setBackground(new Color(214, 233, 230));
		btnVolver.setBounds(190, 253, 91, 27);
		contentPane.add(btnVolver);
	}
	protected void volver() {
		// TODO Auto-generated method stub
		dispose();
	}

	public void mostrarDatosConTableModel() {
		// TODO Auto-generated method stub
		DefaultTableModel modelo = new DefaultTableModel();
		tablaProveedores = new JTable();
		tablaProveedores.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e){
			miCoordinador.pasarDatosProveedor(pasarDatos(e));
		dispose();
		}
		});
		tablaProveedores.setModel(modelo);
		modelo.addColumn("ID");
		modelo.addColumn("Nombre");
		modelo.addColumn("Contacto");
		modelo.addColumn("Direccion");
		
		ProveedorDAO miProveedor = new ProveedorDAO();
		miProveedor.añadirTablaProveedor(modelo);
		
		scrollPane.setViewportView(tablaProveedores);
	
	
	}
	protected ProveedorVO pasarDatos(MouseEvent e) {
		// TODO Auto-generated method stub
		ProveedorVO miProveedorVO = new ProveedorVO();
		int row = tablaProveedores.rowAtPoint(e.getPoint());
		miProveedorVO.setIdProveedor(Integer.valueOf(tablaProveedores.getValueAt(row, 0).toString()));
		miProveedorVO.setNombre(tablaProveedores.getValueAt(row, 1).toString());
		miProveedorVO.setContacto(tablaProveedores.getValueAt(row, 2).toString());
		miProveedorVO.setDireccion(tablaProveedores.getValueAt(row, 3).toString());
		return miProveedorVO;
	}


	public Coordinador getMiCoordinador() {
		return miCoordinador;
	}

	public void setMiCoordinador(Coordinador miCoordinador) {
		this.miCoordinador = miCoordinador;
	}


}
