package Vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Controlador.Coordinador;

import java.awt.FlowLayout;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaPrincipal extends JFrame {

	private Coordinador miCoordinador;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {
		setBackground(new Color(255, 255, 255));
		setTitle("Menú");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 504, 379);
		setLocationRelativeTo(null);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(201, 230, 231));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 2, 2);
		contentPane.add(scrollPane);
		
		JLabel lblMenu = new JLabel("Autoservicio Los Angeles");
		lblMenu.setFont(new Font("Georgia", Font.BOLD, 24));
		lblMenu.setForeground(new Color(30, 55, 51));
		lblMenu.setHorizontalAlignment(SwingConstants.CENTER);
		lblMenu.setBounds(55, 31, 374, 194);
		contentPane.add(lblMenu);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(214, 233, 230));
		panel.setBounds(55, 236, 374, 48);
		contentPane.add(panel);
		
		JButton btnProductos = new JButton("Productos");
		btnProductos.setForeground(new Color(30, 55, 51));
		btnProductos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				producto();
			}
		});
		btnProductos.setBackground(new Color(214, 233, 230));
		btnProductos.setFont(new Font("SansSerif", Font.PLAIN, 13));
		panel.add(btnProductos);
		
		JButton btnProveedores = new JButton("Proveedores");
		btnProveedores.setForeground(new Color(30, 55, 51));
		btnProveedores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				proveedores();
			}
		});
		btnProveedores.setBackground(new Color(214, 233, 230));
		btnProveedores.setFont(new Font("SansSerif", Font.PLAIN, 13));
		panel.add(btnProveedores);
		
		JButton btnMovimientos = new JButton("Movimientos");
		btnMovimientos.setForeground(new Color(30, 55, 51));
		btnMovimientos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				movimiento();
			}
		});
		btnMovimientos.setBackground(new Color(214, 233, 230));
		btnMovimientos.setFont(new Font("SansSerif", Font.PLAIN, 13));
		panel.add(btnMovimientos);
	}

	protected void movimiento() {
		// TODO Auto-generated method stub
		miCoordinador.mostrarVentanaMovimiento();
	}

	protected void proveedores() {
		// TODO Auto-generated method stub
		miCoordinador.mostrarVentanaProveedores();
	}

	protected void producto() {
		// TODO Auto-generated method stub
		miCoordinador.mostrarVentanaProducto();
	}

	public Coordinador getMiCoordinador() {
		return miCoordinador;
	}

	public void setMiCoordinador(Coordinador miCoordinador) {
		this.miCoordinador = miCoordinador;
	}
}
