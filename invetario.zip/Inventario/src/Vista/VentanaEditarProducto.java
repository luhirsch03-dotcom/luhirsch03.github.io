package Vista;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Controlador.Coordinador;
import Modelo.ProductosDAO;
import Modelo.ProductosVO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class VentanaEditarProducto extends JFrame {

	private JPanel contentPane;
	private JTextField txtPrecioUnidadActual;
	private JTextField txtStockActual;
	private JTextField txtNombreViejo;
	private JTextField txtDescripcionVieja;
	private JTextField txtPrecioUnidadViejo;
	private JTextField txtStockViejo;
	private Coordinador miCoordinador;
	public Coordinador getMiCoordinador() {
		return miCoordinador;
	}

	public void setMiCoordinador(Coordinador miCoordinador) {
		this.miCoordinador = miCoordinador;
	}

	private JTextField txtID;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaEditarProducto frame = new VentanaEditarProducto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaEditarProducto() {
		setTitle("Editor Producto");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 494, 370);
		setLocationRelativeTo(null);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(201, 230, 231));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblModificarProductos = new JLabel("Modificar Productos");
		lblModificarProductos.setBounds(10, 11, 198, 21);
		lblModificarProductos.setHorizontalAlignment(SwingConstants.LEFT);
		lblModificarProductos.setForeground(new Color(30, 55, 51));
		lblModificarProductos.setFont(new Font("Georgia", Font.BOLD, 18));
		contentPane.add(lblModificarProductos);
		
		JLabel lblPreciounidadActual = new JLabel("Precio por Unidad");
		lblPreciounidadActual.setForeground(new Color(30, 55, 51));
		lblPreciounidadActual.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblPreciounidadActual.setBounds(97, 184, 119, 23);
		contentPane.add(lblPreciounidadActual);
		
		txtPrecioUnidadActual = new JTextField();
		txtPrecioUnidadActual.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtPrecioUnidadActual.setColumns(10);
		txtPrecioUnidadActual.setBounds(93, 206, 103, 20);
		contentPane.add(txtPrecioUnidadActual);
		
		JLabel lblStockActual = new JLabel("Stock");
		lblStockActual.setForeground(new Color(30, 55, 51));
		lblStockActual.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblStockActual.setBounds(289, 184, 61, 23);
		contentPane.add(lblStockActual);
		
		txtStockActual = new JTextField();
		txtStockActual.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtStockActual.setColumns(10);
		txtStockActual.setBounds(289, 206, 95, 20);
		contentPane.add(txtStockActual);
		
		JLabel lblNombreViejo = new JLabel("Nombre");
		lblNombreViejo.setForeground(new Color(30, 55, 51));
		lblNombreViejo.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblNombreViejo.setBounds(10, 71, 66, 23);
		contentPane.add(lblNombreViejo);
		
		txtNombreViejo = new JTextField();
		txtNombreViejo.setEditable(false);
		txtNombreViejo.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtNombreViejo.setColumns(10);
		txtNombreViejo.setBounds(10, 93, 86, 20);
		contentPane.add(txtNombreViejo);
		
		JLabel lblDescripcionViejo = new JLabel("Descripcion");
		lblDescripcionViejo.setForeground(new Color(30, 55, 51));
		lblDescripcionViejo.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblDescripcionViejo.setBounds(123, 71, 83, 23);
		contentPane.add(lblDescripcionViejo);
		
		txtDescripcionVieja = new JTextField();
		txtDescripcionVieja.setEditable(false);
		txtDescripcionVieja.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtDescripcionVieja.setColumns(10);
		txtDescripcionVieja.setBounds(123, 93, 96, 20);
		contentPane.add(txtDescripcionVieja);
		
		JLabel lblPreciounidadViejo = new JLabel("Precio por Unidad");
		lblPreciounidadViejo.setForeground(new Color(30, 55, 51));
		lblPreciounidadViejo.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblPreciounidadViejo.setBounds(246, 71, 119, 23);
		contentPane.add(lblPreciounidadViejo);
		
		txtPrecioUnidadViejo = new JTextField();
		txtPrecioUnidadViejo.setEditable(false);
		txtPrecioUnidadViejo.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtPrecioUnidadViejo.setColumns(10);
		txtPrecioUnidadViejo.setBounds(246, 93, 103, 20);
		contentPane.add(txtPrecioUnidadViejo);
		
		txtStockViejo = new JTextField();
		txtStockViejo.setEditable(false);
		txtStockViejo.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtStockViejo.setColumns(10);
		txtStockViejo.setBounds(376, 93, 95, 20);
		contentPane.add(txtStockViejo);
		
		JLabel lblStockViejo = new JLabel("Stock");
		lblStockViejo.setForeground(new Color(30, 55, 51));
		lblStockViejo.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblStockViejo.setBounds(375, 71, 66, 23);
		contentPane.add(lblStockViejo);
		
		JLabel lblDatosActualizados = new JLabel("Ingrese datos actuales:");
		lblDatosActualizados.setForeground(new Color(30, 55, 51));
		lblDatosActualizados.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblDatosActualizados.setBounds(10, 156, 151, 23);
		contentPane.add(lblDatosActualizados);
		
		JLabel lblDatosAntiguos = new JLabel("Datos Antiguos:");
		lblDatosAntiguos.setForeground(new Color(30, 55, 51));
		lblDatosAntiguos.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblDatosAntiguos.setBounds(10, 43, 151, 23);
		contentPane.add(lblDatosAntiguos);
		
		JButton btnAtras = new JButton("Atras");
		btnAtras.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnAtras.setBounds(331, 277, 110, 27);
		contentPane.add(btnAtras);
		btnAtras.setForeground(new Color(30, 55, 51));
		btnAtras.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnAtras.setBackground(new Color(214, 233, 230));
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiar();
			}
		});
		btnCancelar.setBounds(184, 277, 110, 27);
		contentPane.add(btnCancelar);
		btnCancelar.setForeground(new Color(30, 55, 51));
		btnCancelar.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnCancelar.setBackground(new Color(214, 233, 230));
		
		JButton btnActualizar = new JButton("Actualizar");
		btnActualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ActualizarProducto();
			}
		});
		btnActualizar.setBounds(37, 277, 110, 27);
		contentPane.add(btnActualizar);
		btnActualizar.setForeground(new Color(30, 55, 51));
		btnActualizar.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnActualizar.setBackground(new Color(214, 233, 230));
		
		txtID = new JTextField();
		txtID.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtID.setColumns(10);
		txtID.setBounds(331, 33, 36, 20);
		contentPane.add(txtID);
		
		JLabel lblID = new JLabel("ID");
		lblID.setForeground(new Color(30, 55, 51));
		lblID.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblID.setBounds(331, 12, 36, 23);
		contentPane.add(lblID);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Buscar();
				habilita(false,false,false,false,false);
			}
		});
		btnBuscar.setForeground(new Color(30, 55, 51));
		btnBuscar.setFont(new Font("SansSerif", Font.PLAIN, 9));
		btnBuscar.setBackground(new Color(214, 233, 230));
		btnBuscar.setBounds(396, 31, 75, 26);
		contentPane.add(btnBuscar);
	}
	protected void limpiar() {
		// TODO Auto-generated method stub
		txtID.setText("");
		txtNombreViejo.setText("");
		txtDescripcionVieja.setText("");
		txtPrecioUnidadViejo.setText("");
		txtStockViejo.setText("");
		txtPrecioUnidadActual.setText("");
		txtStockActual.setText("");
		
		habilita(true,false,false,false,false);
	}

	protected void habilita(boolean id, boolean nombre, boolean descripcion, boolean PrecioUnidad, boolean Stock) {
		// TODO Auto-generated method stub
		txtID.setEditable(id);
		txtNombreViejo.setEditable(nombre);
		txtDescripcionVieja.setEditable(descripcion);
		txtPrecioUnidadViejo.setEditable(PrecioUnidad);
		txtStockViejo.setEditable(Stock);
	}

	protected void Buscar() {
		// TODO Auto-generated method stub
		int idProducto = Integer.parseInt(txtID.getText());
		ProductosDAO productosDAO = new ProductosDAO();
		productosDAO.BuscarProducto(idProducto, VentanaEditarProducto.this);
		habilita (false,true,true,true,true);
	}

	private ProductosVO cargarDatosEnTextfield() { 
		ProductosVO miProductoVO = new ProductosVO();
	    
	    // Obtener los valores de los componentes de la interfaz gráfica
	    miProductoVO.setIdProducto(Integer.parseInt(txtID.getText()));
	    miProductoVO.setNombre(txtNombreViejo.getText());
	    miProductoVO.setDescripcion(txtDescripcionVieja.getText());
	    miProductoVO.setPrecioUnitario(Double.parseDouble(txtPrecioUnidadViejo.getText()));
	    miProductoVO.setStock(Integer.parseInt(txtStockViejo.getText()));
	    
	    return miProductoVO;
	}

	protected void ActualizarProducto() {
		// TODO Auto-generated method stub
		 try {
		        // Obtener los datos actualizados de los TextField
		        int idProducto = Integer.parseInt(txtID.getText());
		        double precioUnitario = Double.parseDouble(txtPrecioUnidadActual.getText());
		        int stock = Integer.parseInt(txtStockActual.getText());

		        // Validación de datos (ejemplo)
		        if (precioUnitario <= 0 || stock < 0) {
		            JOptionPane.showMessageDialog(null, "Precio y stock deben ser valores positivos.", "Error", JOptionPane.ERROR_MESSAGE);
		            return;
		        }

		        // Crear un objeto ProductosVO y llenarlo con los datos actualizados
		        ProductosVO miProductoVo = new ProductosVO();
		        miProductoVo.setIdProducto(idProducto);
		        miProductoVo.setPrecioUnitario(precioUnitario);
		        miProductoVo.setStock(stock);

		        // Llamar al método EditarProducto del coordinador
		       miCoordinador.EditarProducto(miProductoVo);

		        JOptionPane.showMessageDialog(null, "Producto actualizado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

		        // Limpiar campos (opcional)
		        txtPrecioUnidadActual.setText("");
		        txtStockActual.setText("");

		    } catch (NumberFormatException e) {
		        JOptionPane.showMessageDialog(null, "Por favor, ingrese solo números en los campos de precio y stock.", "Error", JOptionPane.ERROR_MESSAGE);
		    } finally {
		        habilita(true, false, false, false, false);
		    }
		}
	
	 

	public void setNombreViejo(String string) {
		// TODO Auto-generated method stub
		txtNombreViejo.setText(string);
	}

	public void setIdProducto(String valueOf) {
		// TODO Auto-generated method stub
		 txtID.setText(valueOf);
	}
	public void setDescripcionVieja(String string) {
		// TODO Auto-generated method stub
		txtDescripcionVieja.setText(string);
	}
	public void setPrecioUnidadViejo(String valueOf) {
		// TODO Auto-generated method stub
		txtPrecioUnidadViejo.setText(valueOf);
	}
	public void setStockViejo(String valueOf) {
		// TODO Auto-generated method stub
		txtStockViejo.setText(valueOf);
	}

	}
