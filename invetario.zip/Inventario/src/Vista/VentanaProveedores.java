package Vista;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Controlador.Coordinador;
import Modelo.ProveedorDAO;
import Modelo.ProveedorVO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaProveedores extends JFrame {

	private Coordinador miCoordinador;
	private JPanel contentPane;
	private JTextField txtNom;
	private JTextField txtCont;
	private JTextField txtGmail;
	private JButton btnBuscar, btnEliminar;
	private JTextField txtID;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaProveedores frame = new VentanaProveedores();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaProveedores() {
		setTitle("Registrar Proveedores");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 365, 290);
		contentPane = new JPanel();
		setLocationRelativeTo(null);
		setResizable(false);
		contentPane.setBackground(new Color(201, 230, 231));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRegistrarProveedores = new JLabel("Registrar Proveedores");
		lblRegistrarProveedores.setHorizontalAlignment(SwingConstants.CENTER);
		lblRegistrarProveedores.setForeground(new Color(30, 55, 51));
		lblRegistrarProveedores.setFont(new Font("Georgia", Font.BOLD, 18));
		lblRegistrarProveedores.setBounds(47, 11, 244, 54);
		contentPane.add(lblRegistrarProveedores);
		
		JLabel lblNombreProveedor = new JLabel("Nombre Proveedor");
		lblNombreProveedor.setForeground(new Color(30, 55, 51));
		lblNombreProveedor.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblNombreProveedor.setBounds(19, 91, 117, 23);
		contentPane.add(lblNombreProveedor);
		
		JLabel lblContacto = new JLabel("Contacto");
		lblContacto.setForeground(new Color(30, 55, 51));
		lblContacto.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblContacto.setBounds(19, 125, 72, 23);
		contentPane.add(lblContacto);
		
		JLabel lblGmail = new JLabel("Gmail");
		lblGmail.setForeground(new Color(30, 55, 51));
		lblGmail.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblGmail.setBounds(19, 159, 46, 23);
		contentPane.add(lblGmail);
		
		txtNom = new JTextField();
		txtNom.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtNom.setColumns(10);
		txtNom.setBounds(135, 93, 117, 20);
		contentPane.add(txtNom);
		
		txtCont = new JTextField();
		txtCont.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtCont.setColumns(10);
		txtCont.setBounds(82, 125, 207, 20);
		contentPane.add(txtCont);
		
		txtGmail = new JTextField();
		txtGmail.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtGmail.setColumns(10);
		txtGmail.setBounds(82, 159, 244, 20);
		contentPane.add(txtGmail);
		
		JButton btnGuardar = new JButton("Guardar");
		
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				guardar();
				Habilitar(false, true, true, true ,true, true);
				
			}
		});
		btnGuardar.setForeground(new Color(30, 55, 51));
		btnGuardar.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnGuardar.setBackground(new Color(214, 233, 230));
		btnGuardar.setBounds(19, 213, 91, 27);
		contentPane.add(btnGuardar);
		
		btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				miCoordinador.mostrarVentanaBuscarProveedor();
				busca();
			}
		});
		btnBuscar.setForeground(new Color(30, 55, 51));
		btnBuscar.setFont(new Font("SansSerif", Font.PLAIN, 9));
		btnBuscar.setBackground(new Color(214, 233, 230));
		btnBuscar.setBounds(262, 94, 61, 20);
		contentPane.add(btnBuscar);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.setEnabled(false);
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				eliminar();
			}
		});
		btnEliminar.setForeground(new Color(30, 55, 51));
		btnEliminar.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnEliminar.setBackground(new Color(214, 233, 230));
		btnEliminar.setBounds(129, 213, 91, 27);
		contentPane.add(btnEliminar);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				volver();
			}
		});
		btnVolver.setForeground(new Color(30, 55, 51));
		btnVolver.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnVolver.setBackground(new Color(214, 233, 230));
		btnVolver.setBounds(239, 213, 91, 27);
		contentPane.add(btnVolver);
		
		JLabel lblID = new JLabel("ID");
		lblID.setForeground(new Color(30, 55, 51));
		lblID.setFont(new Font("SansSerif", Font.PLAIN, 12));
		lblID.setBounds(19, 50, 36, 23);
		contentPane.add(lblID);
		
		txtID = new JTextField();
		txtID.setEnabled(false);
		txtID.setEditable(false);
		txtID.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtID.setColumns(10);
		txtID.setBounds(19, 72, 36, 20);
		contentPane.add(txtID);
	}


	protected void busca() {
		// TODO Auto-generated method stub
		Habilitar(true, true, true, true, true, true);
	}

	

	public void limpiar() {
		txtID.setText("");
		txtNom.setText("");
		txtCont.setText("");
		txtGmail.setText("");
	}
	protected void volver() {
		// TODO Auto-generated method stub
		dispose();
	}

	protected void Habilitar(boolean id, boolean nom, boolean contacto, boolean direccion, boolean bBuscar, boolean bEliminar) {
		// TODO Auto-generated method stub
		txtID.setEditable(id);
		txtNom.setEditable(nom);
		txtCont.setEditable(contacto);
		txtGmail.setEditable(direccion);
		btnBuscar.setEnabled(bBuscar);
		btnEliminar.setEnabled(bEliminar);
	}

	protected void guardar() {
		    // TODO Auto-generated method stub
		    try {
		        // Obtener datos de los campos de texto
		       // int idProveedor = Integer.parseInt(txtID.getText());
		    	
		        String nombre = txtNom.getText();
		        String contacto = txtCont.getText();
		        String direccion = txtGmail.getText();

		        // Validar datos antes de crear el objeto VO
		        if (nombre.isEmpty() || contacto.isEmpty() || direccion.isEmpty()) {
		            throw new IllegalArgumentException("Todos los campos deben estar llenos.");
		        }

		        // Crear el objeto VO y asignar los valores
		        ProveedorVO miProveedorVO = new ProveedorVO();
		        miProveedorVO.setNombre(nombre);
		        miProveedorVO.setContacto(contacto);
		        miProveedorVO.setDireccion(direccion);

		        ProveedorDAO proveedorDAO = new ProveedorDAO();
				// Llamar al método para agregar el proveedor
		        proveedorDAO.agregarProveedor(miProveedorVO);

		        // Mostrar mensaje de éxito
		        JOptionPane.showMessageDialog(this, "Proveedor agregado correctamente.", "Éxito",
		                JOptionPane.INFORMATION_MESSAGE);
		       
		    } 
		    // Capturar cualquier otra excepción que pueda ocurrir
		    catch (IllegalArgumentException e) {
		        JOptionPane.showMessageDialog(this, e.getMessage());
		    } 
		    catch (Exception e) {
		        JOptionPane.showMessageDialog(this, "Error al agregar el proveedor: " + e.getMessage());
		    }
		limpiar();
		Habilitar( false, true, true, true ,true, true);
	}

	protected void eliminar() {
		// TODO Auto-generated method stub
		int respuesta = JOptionPane.showConfirmDialog(null, "¿Esta seguro de eliminar el producto?",
				"Confirmacion", JOptionPane.YES_NO_OPTION);
		if (respuesta == JOptionPane.YES_NO_OPTION) {
			miCoordinador.eliminarProveedor(Integer.valueOf(txtID.getText()));
			limpiar();
			}
	}

	public Coordinador getMiCoordinador() {
		return miCoordinador;
	}

	public void setMiCoordinador(Coordinador miCoordinador) {
		this.miCoordinador = miCoordinador;
	}

	public void setNombre(String string) {
		// TODO Auto-generated method stub
		txtNom.setText(string);
		
	}
	public void setContacto(String string) {
		// TODO Auto-generated method stub
		txtCont.setText(string);
	}
	public void setDireccion(String string) {
		// TODO Auto-generated method stub
		txtGmail.setText(string);
	}

	public void mostrarProveedores(ProveedorVO miProveedorVO) {
		// TODO Auto-generated method stub
		txtID.setText(String.valueOf(miProveedorVO.getIdProveedor()));
		txtNom.setText(miProveedorVO.getNombre());
		txtCont.setText(miProveedorVO.getContacto());
		txtGmail.setText(miProveedorVO.getDireccion());
	}
}
