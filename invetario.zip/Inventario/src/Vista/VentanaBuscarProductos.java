package Vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Controlador.Coordinador;
import Modelo.ProductosDAO;
import Modelo.ProductosVO;
import Modelo.ProveedorVO;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaBuscarProductos extends JFrame {

	private JPanel contentPane;
	private Coordinador miCoordinador;
	private JScrollPane scrollPane;
	private JTable TablaProducto;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaBuscarProductos frame = new VentanaBuscarProductos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaBuscarProductos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 481, 326);
		contentPane = new JPanel();
		
		contentPane.setBackground(new Color(201, 230, 231));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		setResizable(false);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 434, 216);
		contentPane.add(scrollPane);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				volver();
			}
		});
		btnVolver.setForeground(new Color(30, 55, 51));
		btnVolver.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnVolver.setBackground(new Color(214, 233, 230));
		btnVolver.setBounds(190, 249, 91, 27);
		contentPane.add(btnVolver);
	}
	
	protected void volver() {
		// TODO Auto-generated method stub
		dispose();
	}

	public void mostrarDatosConTableModel() {
		// TODO Auto-generated method stub
		DefaultTableModel modelo = new DefaultTableModel();
		TablaProducto = new JTable();
		TablaProducto.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				miCoordinador.pasarDatosProductos(pasarDatosProducto(e));
				dispose();
			}
		});
		TablaProducto.setModel(modelo);
		modelo.addColumn("ID");
		modelo.addColumn("Nombre");
		modelo.addColumn("Descripcion");
		modelo.addColumn("Precio por unidad");
		modelo.addColumn("Stock");
		
		ProductosDAO miProductosDAO = new ProductosDAO();
		miProductosDAO.añadirTablaProductos(modelo);
		
		scrollPane.setViewportView(TablaProducto);

	}

	protected ProductosVO pasarDatosProducto(MouseEvent e) {
		// TODO Auto-generated method stub
		ProductosVO miProductoVO = new ProductosVO();
	    int row = TablaProducto.rowAtPoint(e.getPoint());
	    
	    // Establecer los valores del producto desde la tabla
	    miProductoVO.setIdProducto(Integer.valueOf(TablaProducto.getValueAt(row, 0).toString()));
	    miProductoVO.setNombre(TablaProducto.getValueAt(row, 1).toString());
	    miProductoVO.setDescripcion(TablaProducto.getValueAt(row, 2).toString());
	    miProductoVO.setPrecioUnitario(Double.valueOf(TablaProducto.getValueAt(row, 3).toString()));
	    miProductoVO.setStock(Integer.valueOf(TablaProducto.getValueAt(row, 4).toString()));
	    
	    return miProductoVO;
	}
	
	public Coordinador getMiCoordinador() {
		return miCoordinador;
	}

	public void setMiCoordinador(Coordinador miCoordinador) {
		this.miCoordinador = miCoordinador;
	}
}
