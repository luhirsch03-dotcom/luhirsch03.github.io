package Vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Controlador.Coordinador;
import Modelo.ProductosDAO;
import Modelo.ProductosVO;


import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.ScrollPane;

import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;

public class VentanaProducto extends JFrame {

	private Coordinador miCoordinador;
	private JPanel contentPane;
	private JTable TablaProducto;
	private JTextField txtID;
	private JTextField txtNombre;
	private JTextField txtDescripcion;
	private JTextField txtPrecioUnidad;
	private JTextField txtStock;
	private JButton btnAgregar;
	private JButton btnLimpiar;
	private JButton btnEditar; 
	private JButton btnEliminar;
	private JButton btnGuardar;
	private JScrollPane scrollPane;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaProducto frame = new VentanaProducto();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaProducto() {
		setTitle("Productos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 598, 426);
		setLocationRelativeTo(null);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(201, 230, 231));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblListaDeProductos = new JLabel("Lista de Productos");
		lblListaDeProductos.setForeground(new Color(30, 55, 51));
		lblListaDeProductos.setHorizontalAlignment(SwingConstants.LEFT);
		lblListaDeProductos.setFont(new Font("Georgia", Font.BOLD, 18));
		lblListaDeProductos.setBounds(10, 11, 200, 54);
		contentPane.add(lblListaDeProductos);
		
		JLabel lblID = new JLabel("ID");
		lblID.setForeground(new Color(30, 55, 51));
		lblID.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblID.setBounds(27, 65, 36, 23);
		contentPane.add(lblID);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setForeground(new Color(30, 55, 51));
		lblNombre.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblNombre.setBounds(90, 65, 66, 23);
		contentPane.add(lblNombre);
		
		JLabel lblDescripcion = new JLabel("Descripcion");
		lblDescripcion.setForeground(new Color(30, 55, 51));
		lblDescripcion.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblDescripcion.setBounds(209, 65, 83, 23);
		contentPane.add(lblDescripcion);
		
		JLabel lblPreciounidad = new JLabel("Precio por Unidad");
		lblPreciounidad.setForeground(new Color(30, 55, 51));
		lblPreciounidad.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblPreciounidad.setBounds(326, 65, 119, 23);
		contentPane.add(lblPreciounidad);
		
		JLabel lblStock = new JLabel("Stock");
		lblStock.setForeground(new Color(30, 55, 51));
		lblStock.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblStock.setBounds(455, 65, 66, 23);
		contentPane.add(lblStock);
		
		
		
		txtID = new JTextField();
		txtID.setEditable(false);
		txtID.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtID.setBounds(27, 87, 36, 20);
		contentPane.add(txtID);
		txtID.setColumns(10);
		
		txtNombre = new JTextField();
		txtNombre.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtNombre.setColumns(10);
		txtNombre.setBounds(90, 87, 86, 20);
		contentPane.add(txtNombre);
		
		txtDescripcion = new JTextField();
		txtDescripcion.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtDescripcion.setColumns(10);
		txtDescripcion.setBounds(203, 87, 96, 20);
		contentPane.add(txtDescripcion);
		
		txtPrecioUnidad = new JTextField();
		txtPrecioUnidad.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtPrecioUnidad.setColumns(10);
		txtPrecioUnidad.setBounds(326, 87, 103, 20);
		contentPane.add(txtPrecioUnidad);
		
		txtStock = new JTextField();
		txtStock.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtStock.setColumns(10);
		txtStock.setBounds(456, 87, 95, 20);
		contentPane.add(txtStock);
		
		btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AgregarProducto();
				
			}
		});
		btnAgregar.setForeground(new Color(30, 55, 51));
		btnAgregar.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnAgregar.setBackground(new Color(214, 233, 230));
		btnAgregar.setBounds(101, 338, 91, 27);
		contentPane.add(btnAgregar);
		
		btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				miCoordinador.mostrarVentanaEditarProducto();
			}
		});
		btnEditar.setForeground(new Color(30, 55, 51));
		btnEditar.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnEditar.setBackground(new Color(214, 233, 230));
		btnEditar.setBounds(197, 338, 91, 27);
		contentPane.add(btnEditar);
		
		btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EliminarProducto();
			}
		});
		btnEliminar.setForeground(new Color(30, 55, 51));
		btnEliminar.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnEliminar.setBackground(new Color(214, 233, 230));
		btnEliminar.setBounds(293, 338, 91, 27);
		contentPane.add(btnEliminar);
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				volver();
			}
		});
		btnVolver.setForeground(new Color(30, 55, 51));
		btnVolver.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnVolver.setBackground(new Color(214, 233, 230));
		btnVolver.setBounds(485, 338, 91, 27);
		contentPane.add(btnVolver);
		
		btnLimpiar = new JButton("Limpiar");
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiar();
			}
		});
		btnLimpiar.setForeground(new Color(30, 55, 51));
		btnLimpiar.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnLimpiar.setBackground(new Color(214, 233, 230));
		btnLimpiar.setBounds(389, 338, 91, 27);
		contentPane.add(btnLimpiar);
		
		btnGuardar = new JButton("Guardar");
		btnGuardar.setEnabled(false);
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				guardarProducto();
			}
		});
		btnGuardar.setForeground(new Color(30, 55, 51));
		btnGuardar.setFont(new Font("SansSerif", Font.PLAIN, 13));
		btnGuardar.setBackground(new Color(214, 233, 230));
		btnGuardar.setBounds(5, 338, 91, 27);
		contentPane.add(btnGuardar);
	
		scrollPane = new JScrollPane();
		scrollPane.setBounds(25, 136, 529, 165);
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		
		
	}
	public void mostrarDatosConTableModel() {
		// TODO Auto-generated method stub
		DefaultTableModel modelo = new DefaultTableModel();
		TablaProducto = new JTable();
		TablaProducto.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				habilita(true,true,true,true,true,true,true,true,true,true);
				miCoordinador.pasarDatosProductos(pasarDatos(e));
				
			}
		});
		TablaProducto.setModel(modelo);
		modelo.addColumn("ID");
		modelo.addColumn("Nombre");
		modelo.addColumn("Descripcion");
		modelo.addColumn("Precio por unidad");
		modelo.addColumn("Stock");
		
		ProductosDAO miProductosDAO = new ProductosDAO();
		miProductosDAO.añadirTablaProductos(modelo);
		
		scrollPane.setViewportView(TablaProducto);

	}
	protected ProductosVO pasarDatos(MouseEvent e) {
	    ProductosVO miProductoVO = new ProductosVO();
	    int row = TablaProducto.rowAtPoint(e.getPoint());
	    
	    // Establecer los valores del producto desde la tabla
	    miProductoVO.setIdProducto(Integer.valueOf(TablaProducto.getValueAt(row, 0).toString()));
	    miProductoVO.setNombre(TablaProducto.getValueAt(row, 1).toString());
	    miProductoVO.setDescripcion(TablaProducto.getValueAt(row, 2).toString());
	    miProductoVO.setPrecioUnitario(Double.valueOf(TablaProducto.getValueAt(row, 3).toString()));
	    miProductoVO.setStock(Integer.valueOf(TablaProducto.getValueAt(row, 4).toString()));
	    
	    return miProductoVO;
	}

	

	protected void EliminarProducto() {
		// TODO Auto-generated method stub
		int respuesta = JOptionPane.showConfirmDialog(null, "¿Esta seguro de eliminar el producto?",
				"Confirmacion", JOptionPane.YES_NO_OPTION);
		if (respuesta == JOptionPane.YES_NO_OPTION) {
			miCoordinador.eliminarProducto(Integer.valueOf(txtID.getText()));
			limpiar();
		}
	}

	protected void guardarProducto() {
		// TODO Auto-generated method stub
		try { 
			// Obtener datos de los campos de texto 
			//int idProducto = Integer.parseInt(txtID.getText());
			String nombre = txtNombre.getText();
			String descripcion = txtDescripcion.getText();
			double precioUnitario = Double.parseDouble(txtPrecioUnidad.getText());
			int stock = Integer.parseInt(txtStock.getText()); 
			// Validar datos antes de crear el objeto VO 
			if (stock < 0)
			{ throw new IllegalArgumentException("El stock no puede ser negativo.");
			}
				
			// Crear el objeto VO y asignar los valores 
		ProductosVO miProductoVO = new ProductosVO();
	//	miProductoVO.setIdProducto(idProducto); 
		// ID generado automáticamente 
		miProductoVO.setNombre(nombre); 
		miProductoVO.setDescripcion(descripcion); 
		miProductoVO.setPrecioUnitario(precioUnitario);
		miProductoVO.setStock(stock);
		// Llamar al método para agregar el producto
		miCoordinador.agregarProducto(miProductoVO); 
		// Mostrar mensaje de éxito 
		JOptionPane.showMessageDialog(this, "Producto agregado correctamente.", "Éxito",
				JOptionPane.INFORMATION_MESSAGE); }
		
		 // Capturar cualquier otra excepción que pueda ocurrir
		catch (NumberFormatException e) {
			
	        JOptionPane.showMessageDialog(null, "Por favor, ingrese valores numéricos válidos.");
			} 
		catch (IllegalArgumentException e) {
	    	
	        JOptionPane.showMessageDialog(null, e.getMessage());
	        } 
		catch (Exception e) {
	       
	        JOptionPane.showMessageDialog(null, "Error al agregar el producto: " + e.getMessage());
	        habilita(false, true, true, true, true, true, true, true,true, true);
	    }
	}

	protected void limpiar() {
		// TODO Auto-generated method stub
		txtID.setText(" ");
		txtNombre.setText(" ");
		txtDescripcion.setText(" ");
		txtPrecioUnidad.setText(" ");
		txtStock.setText(" ");
		
		habilita( true, true, true, true, true, true, false, true, true, true);
		
	}

	public void habilita(boolean id , boolean nombre, boolean descripcion, 
			boolean precioUnidad, boolean stock, boolean bAgregar,boolean bGuardar, boolean bEditar, boolean bEliminar, boolean bLimpiar) {
		// TODO Auto-generated method stub
		
		txtID.setEditable(id);
		txtNombre.setEditable(nombre);
		txtDescripcion.setEditable(descripcion);
		txtPrecioUnidad.setEditable(precioUnidad);
		txtStock.setEditable(stock);
		btnAgregar.setEnabled(bAgregar);
		btnGuardar.setEnabled(bGuardar);
		btnEditar.setEnabled(bEditar);
		btnEliminar.setEnabled(bEliminar);
		btnLimpiar.setEnabled(bLimpiar);
		
		
	}

	protected void AgregarProducto() {
		// TODO Auto-generated method stub
		habilita(false, true, true, true, true, true, true, false, false, true);
	
	}
	public void muestraProducto(ProductosVO miProductoVO) {
	    // Establecer los valores de los campos de texto con los datos del producto
	    txtID.setText(String.valueOf(miProductoVO.getIdProducto()));
	    txtNombre.setText(miProductoVO.getNombre());
	    txtDescripcion.setText(miProductoVO.getDescripcion());
	    txtPrecioUnidad.setText(String.valueOf(miProductoVO.getPrecioUnitario()));
	    txtStock.setText(String.valueOf(miProductoVO.getStock()));

	  
	}


	protected void volver() {
		// TODO Auto-generated method stub
		dispose();
		
	}

	public Coordinador getMiCoordinador() {
		return miCoordinador;
	}

	public void setMiCoordinador(Coordinador miCoordinador) {

		this.miCoordinador = miCoordinador;
	}
}
