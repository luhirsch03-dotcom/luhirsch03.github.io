package Vista;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Controlador.Coordinador;
import Modelo.MovimientoDAO;
import Modelo.MovimientoVO;

import Modelo.ProductosVO;
import Modelo.ProveedorVO;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JLayeredPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class VentanaMovimiento extends JFrame {

	private Coordinador miCoordinador;
	private JPanel contentPane;
	private JTextField txtID;
	private JTextField txtNomProd;
	private JTextField txtIdProd;
	private JTextField txtNombreProv;
	private JTextField txtIdProv;
	private JTextField txtFecha;
	private JTextField txtCant;
	private JComboBox cbMovimiento;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaMovimiento frame = new VentanaMovimiento();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaMovimiento() {
		setTitle("Movimiento");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 494, 389);
		contentPane = new JPanel();
		setLocationRelativeTo(null);
		setResizable(false);
		contentPane.setBackground(new Color(201, 230, 231));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIdMovimiento = new JLabel("Id Movimiento");
		lblIdMovimiento.setForeground(new Color(30, 55, 51));
		lblIdMovimiento.setFont(new Font("SansSerif", Font.PLAIN, 13));
		lblIdMovimiento.setBounds(10, 315, 91, 23);
		contentPane.add(lblIdMovimiento);
		
		txtID = new JTextField();
		txtID.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		txtID.setEditable(false);
		txtID.setColumns(10);
		txtID.setBounds(109, 316, 23, 23);
		contentPane.add(txtID);
		
		JLabel lblFormularioDeMovimiento = new JLabel("Formulario de movimiento");
		lblFormularioDeMovimiento.setHorizontalAlignment(SwingConstants.LEFT);
		lblFormularioDeMovimiento.setForeground(new Color(30, 55, 51));
		lblFormularioDeMovimiento.setFont(new Font("Georgia", Font.BOLD, 18));
		lblFormularioDeMovimiento.setBounds(10, 0, 292, 47);
		contentPane.add(lblFormularioDeMovimiento);
		
		JLabel lblProducto = new JLabel("Producto");
		lblProducto.setForeground(new Color(30, 55, 51));
		lblProducto.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblProducto.setBounds(30, 58, 59, 23);
		contentPane.add(lblProducto);
		
		JLabel lblNombreDelPrpducto = new JLabel("Nombre del Producto:");
		lblNombreDelPrpducto.setForeground(new Color(30, 55, 51));
		lblNombreDelPrpducto.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblNombreDelPrpducto.setBounds(30, 92, 122, 23);
		contentPane.add(lblNombreDelPrpducto);
		
		txtNomProd = new JTextField();
		txtNomProd.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		txtNomProd.setEditable(false);
		txtNomProd.setColumns(10);
		txtNomProd.setBounds(137, 93, 126, 23);
		contentPane.add(txtNomProd);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BuscarProducto();
			}
		});
		btnBuscar.setForeground(new Color(30, 55, 51));
		btnBuscar.setFont(new Font("SansSerif", Font.PLAIN, 10));
		btnBuscar.setBackground(new Color(214, 233, 230));
		btnBuscar.setBounds(82, 59, 70, 23);
		contentPane.add(btnBuscar);
		
		txtIdProd = new JTextField();
		txtIdProd.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		txtIdProd.setEditable(false);
		txtIdProd.setColumns(10);
		txtIdProd.setBounds(293, 93, 30, 23);
		contentPane.add(txtIdProd);
		
		JLabel lblIdProd = new JLabel("Id");
		lblIdProd.setHorizontalAlignment(SwingConstants.CENTER);
		lblIdProd.setForeground(new Color(30, 55, 51));
		lblIdProd.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblIdProd.setBounds(262, 92, 30, 23);
		contentPane.add(lblIdProd);
		
		JLabel lblProveedor = new JLabel("Proveedor");
		lblProveedor.setForeground(new Color(30, 55, 51));
		lblProveedor.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblProveedor.setBounds(30, 126, 59, 23);
		contentPane.add(lblProveedor);
		
		JButton btnBuscarProv = new JButton("Buscar");
		btnBuscarProv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buscarProveedor();
			}
		});
		btnBuscarProv.setForeground(new Color(30, 55, 51));
		btnBuscarProv.setFont(new Font("SansSerif", Font.PLAIN, 10));
		btnBuscarProv.setBackground(new Color(214, 233, 230));
		btnBuscarProv.setBounds(82, 126, 70, 23);
		contentPane.add(btnBuscarProv);
		
		JLabel lblNombreDelProveedor = new JLabel("Nombre del Proveedor:");
		lblNombreDelProveedor.setForeground(new Color(30, 55, 51));
		lblNombreDelProveedor.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblNombreDelProveedor.setBounds(30, 160, 122, 23);
		contentPane.add(lblNombreDelProveedor);
		
		txtNombreProv = new JTextField();
		txtNombreProv.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		txtNombreProv.setEditable(false);
		txtNombreProv.setColumns(10);
		txtNombreProv.setBounds(150, 161, 126, 23);
		contentPane.add(txtNombreProv);
		
		JLabel lblIdProv = new JLabel("Id");
		lblIdProv.setHorizontalAlignment(SwingConstants.CENTER);
		lblIdProv.setForeground(new Color(30, 55, 51));
		lblIdProv.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblIdProv.setBounds(272, 160, 30, 23);
		contentPane.add(lblIdProv);
		
		txtIdProv = new JTextField();
		txtIdProv.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		txtIdProv.setEditable(false);
		txtIdProv.setColumns(10);
		txtIdProv.setBounds(300, 161, 30, 23);
		contentPane.add(txtIdProv);
		
		JLabel lblFecha = new JLabel("Fecha:");
		lblFecha.setForeground(new Color(30, 55, 51));
		lblFecha.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblFecha.setBounds(30, 194, 59, 23);
		contentPane.add(lblFecha);
		
		txtFecha = new JTextField();
		txtFecha.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		txtFecha.setColumns(10);
		txtFecha.setBounds(82, 194, 91, 23);
		contentPane.add(txtFecha);
		
		txtCant = new JTextField();
		txtCant.setFont(new Font("Times New Roman", Font.PLAIN, 11));
		txtCant.setColumns(10);
		txtCant.setBounds(239, 195, 91, 23);
		contentPane.add(txtCant);
		
		JLabel lblCantidad = new JLabel("Cantidad:");
		lblCantidad.setForeground(new Color(30, 55, 51));
		lblCantidad.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblCantidad.setBounds(183, 195, 59, 23);
		contentPane.add(lblCantidad);
		
		JLabel lblTipoDeMovimiento = new JLabel("Tipo de movimiento:");
		lblTipoDeMovimiento.setForeground(new Color(30, 55, 51));
		lblTipoDeMovimiento.setFont(new Font("SansSerif", Font.PLAIN, 11));
		lblTipoDeMovimiento.setBounds(30, 231, 110, 23);
		contentPane.add(lblTipoDeMovimiento);
		
		JButton btnReporte = new JButton("Reporte");
		btnReporte.setBounds(375, 96, 89, 23);
		contentPane.add(btnReporte);
		btnReporte.setForeground(new Color(30, 55, 51));
		btnReporte.setFont(new Font("SansSerif", Font.PLAIN, 10));
		btnReporte.setBackground(new Color(214, 233, 230));
		
		JButton btnBuscarMovimiento = new JButton("Buscar ");
		btnBuscarMovimiento.setBounds(142, 316, 89, 23);
		contentPane.add(btnBuscarMovimiento);
		btnBuscarMovimiento.setForeground(new Color(30, 55, 51));
		btnBuscarMovimiento.setFont(new Font("SansSerif", Font.PLAIN, 10));
		btnBuscarMovimiento.setBackground(new Color(214, 233, 230));
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnEliminar.setBounds(374, 170, 91, 23);
		contentPane.add(btnEliminar);
		btnEliminar.setForeground(new Color(30, 55, 51));
		btnEliminar.setFont(new Font("SansSerif", Font.PLAIN, 10));
		btnEliminar.setBackground(new Color(214, 233, 230));
		
		JButton btnGuardarCambios = new JButton("Actualizar");
		btnGuardarCambios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GuardarCambios();
			}
		});
		btnGuardarCambios.setBounds(374, 244, 91, 23);
		contentPane.add(btnGuardarCambios);
		btnGuardarCambios.setForeground(new Color(30, 55, 51));
		btnGuardarCambios.setFont(new Font("SansSerif", Font.PLAIN, 10));
		btnGuardarCambios.setBackground(new Color(214, 233, 230));
		
		JButton btnAgregarMovimiento = new JButton("Agregar ");
		btnAgregarMovimiento.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AgregarDatos();
			}
		});
		btnAgregarMovimiento.setBounds(375, 22, 89, 23);
		contentPane.add(btnAgregarMovimiento);
		btnAgregarMovimiento.setForeground(new Color(30, 55, 51));
		btnAgregarMovimiento.setFont(new Font("SansSerif", Font.PLAIN, 10));
		btnAgregarMovimiento.setBackground(new Color(214, 233, 230));
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				volver();
			}
		});
		btnVolver.setForeground(new Color(30, 55, 51));
		btnVolver.setFont(new Font("SansSerif", Font.PLAIN, 10));
		btnVolver.setBackground(new Color(214, 233, 230));
		btnVolver.setBounds(326, 316, 91, 23);
		contentPane.add(btnVolver);
		
		
		
		cbMovimiento = new JComboBox<>();
		cbMovimiento.setFont(new Font("SansSerif", Font.PLAIN, 11));
		 DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
	        model.addElement("Entrada");
	        model.addElement("Salida");
	        cbMovimiento.setModel(model);
		cbMovimiento.setBounds(137, 232, 111, 22);
		contentPane.add(cbMovimiento);
	}


	protected void AgregarDatos() {
		// TODO Auto-generated method stub
		try {// Obtener datos de los campos de texto
			 int idProducto = Integer.parseInt(txtIdProd.getText()); 
			 int idProveedor = Integer.parseInt(txtIdProv.getText()); 
			 String fechaStr = txtFecha.getText();  
			 String tipoMovimiento = (String)cbMovimiento.getSelectedItem();
			 // Usamos String para capturar el valor del JTextField 
			 int cantidad = Integer.parseInt(txtCant.getText()); 
			 
		SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
		        Date fecha = formato.parse(fechaStr);
		     // Validar la cantidad
		        if (cantidad < 0) {
		            throw new IllegalArgumentException("La cantidad no puede ser negativa.");
		        }
		        
		        // Crear el objeto VO y asignar los valores
		        MovimientoVO miMovimientoVO = new MovimientoVO();
		        miMovimientoVO.setIdProducto(idProducto);
		        miMovimientoVO.setIdProveedor(idProveedor);
		        miMovimientoVO.setFecha(fecha);
		        miMovimientoVO.setTipoMovimiento(tipoMovimiento);
		        miMovimientoVO.setCantidad(cantidad);
	
			 MovimientoDAO movimientoDAO = new MovimientoDAO();
			 movimientoDAO.agregarMovimiento(miMovimientoVO);
			 // Mostrar mensaje de éxito
			 JOptionPane.showMessageDialog(this, "Movimiento guardado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Por favor, ingrese valores numéricos válidos.");
    } catch (ParseException e) {
        JOptionPane.showMessageDialog(null, "Formato de fecha inválido. Debe ser año-mes-día.");
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al guardar el movimiento: " + e.getMessage());
        e.printStackTrace();
    }
}
	
		 
	
	


	protected void GuardarCambios() {
		// TODO Auto-generated method stub
		
	}

	protected void buscarProveedor() {
		// TODO Auto-generated method stub
		miCoordinador.mostrarVentanaBuscarProveedor();
	}

	protected void BuscarProducto() {
		// TODO Auto-generated method stub
		miCoordinador.mostrarVentanaBuscarProducto();
		
	}

	protected void volver() {
		// TODO Auto-generated method stub
		dispose();
	}

	public Coordinador getMiCoordinador() {
		return miCoordinador;
	}

	public void setMiCoordinador(Coordinador miCoordinador) {
		this.miCoordinador = miCoordinador;
	}

	public void mostrarProveedores(ProveedorVO miProveedorVO) {
		// TODO Auto-generated method stub
		txtIdProv.setText(String.valueOf(miProveedorVO.getIdProveedor()));
		txtNombreProv.setText(miProveedorVO.getNombre());
	}

	public void muestraProductos(ProductosVO miProductoVO) {
		// TODO Auto-generated method stub
		txtIdProd.setText(String.valueOf(miProductoVO.getIdProducto()));
		txtNomProd.setText(miProductoVO.getNombre());
	}
}
