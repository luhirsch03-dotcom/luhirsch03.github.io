package Modelo;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import Controlador.Coordinador;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class Reportes {
	private Coordinador miCoordinado; 
	private JasperReport report;
	private JasperPrint reportFilled;
	private JasperViewer viewer;
	private String rutaReporte = "c:\\reportes\\";

	
	public void crearReporteProductosPorPrecio(int precioUnitario) {
	Conexion conex = new Conexion();
	Connection con= conex.getConnection();
	
	Integer pre = Integer.valueOf(precioUnitario);
	Map<String, Object> parametros = new HashMap<>();
	parametros.put("ParaPrecioUnitario",pre);

	try {
		report=(JasperReport)
				JRLoader.loadObjectFromFile(rutaReporte+"ReporteProducto.jasper");
				reportFilled = JasperFillManager.fillReport(report, parametros,con);
				showViewer();
	}catch(JRException e) {
		e.printStackTrace();
		}
	}
	public void showViewer(){
		// se crea la vista y luego se hace visible
			viewer = new JasperViewer(reportFilled, false);
			viewer.setVisible(true);
		}


	public void setMiCoordinador(Coordinador miCoordinador) {
		// TODO Auto-generated method stub
		
	}

	public Coordinador getMiCoordinado() {
		return miCoordinado;
	}

}
